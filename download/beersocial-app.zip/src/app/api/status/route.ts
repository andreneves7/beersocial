/**
 * STATUS ENDPOINT
 * 
 * GET /api/status
 * 
 * Verifica a ligação a todas as bases de dados:
 * - Redis (Cache)
 * - MongoDB (Documentos)
 * - Cassandra (Distribuído)
 */

import { NextResponse } from 'next/server';
import { getRedis } from '@/lib/redis-client';
import { getMongoDB } from '@/lib/mongodb-client';
import { getCassandra } from '@/lib/cassandra-client';

export async function GET() {
  const status = {
    timestamp: new Date().toISOString(),
    databases: {
      redis: { connected: false, purpose: '', error: null as string | null },
      mongodb: { connected: false, purpose: '', error: null as string | null },
      cassandra: { connected: false, purpose: '', error: null as string | null },
    },
    architecture: {
      description: 'Arquitetura poliglota com 3 bases de dados especializadas',
      technologies: [] as Array<{ name: string; purpose: string; endpoints: string[]; structures: string[] }>,
    },
  };

  // Redis - Cache e sessões
  try {
    const redis = await getRedis();
    status.databases.redis.connected = redis.isConnected();
    status.databases.redis.purpose = 'Cache, sessões, contadores, rate limiting, pub/sub';
  } catch (error) {
    status.databases.redis.error = error instanceof Error ? error.message : 'Unknown error';
  }

  // MongoDB - Dados documentais
  try {
    const mongo = await getMongoDB();
    status.databases.mongodb.connected = mongo.isConnected();
    status.databases.mongodb.purpose = 'Users, beers, reviews (embedded comments), friendships, notifications';
  } catch (error) {
    status.databases.mongodb.error = error instanceof Error ? error.message : 'Unknown error';
  }

  // Cassandra - Dados distribuídos
  try {
    const cassandra = await getCassandra();
    status.databases.cassandra.connected = cassandra.isConnected();
    status.databases.cassandra.purpose = 'Timeline (partition by user), messages (partition by conversation), followers';
  } catch (error) {
    status.databases.cassandra.error = error instanceof Error ? error.message : 'Unknown error';
  }

  // Arquitetura
  status.architecture.technologies = [
    {
      name: 'Redis',
      purpose: 'Cache de baixa latência (<1ms), sessões, contadores atómicos, rate limiting',
      endpoints: ['/api/redis/cache', '/api/redis/session', '/api/redis/counters'],
      structures: ['Strings (cache)', 'Hashes (sessões)', 'Sorted Sets (leaderboards)', 'Lists (pesquisas)'],
    },
    {
      name: 'MongoDB',
      purpose: 'Dados documentais - reviews com comentários embedded, perfis flexíveis',
      endpoints: ['/api/mongo/reviews', '/api/beers', '/api/users', '/api/friends'],
      structures: ['Users', 'Beers', 'Reviews (embedded comments[])', 'Friendships', 'Notifications'],
    },
    {
      name: 'Cassandra',
      purpose: 'Dados distribuídos com partition key - timeline, mensagens',
      endpoints: ['/api/cassandra/timeline', '/api/cassandra/messages'],
      structures: [
        'user_timeline (PK: user_id, CK: created_at DESC)',
        'messages (PK: conversation_id, CK: created_at ASC)',
        'followers (PK: user_id, CK: follower_id)',
      ],
    },
  ];

  const allConnected = Object.values(status.databases).every(db => db.connected);

  return NextResponse.json({
    success: allConnected,
    status,
  }, { status: allConnected ? 200 : 503 });
}
